# Adafruit-SSD1306-STM32
This project is porting Adafruit SSD1306 Library based on Arduino Platform also to the STM32 Platform with additional features.

The code has modyfication to the code from Adafruit ,Tilen Majerle, Kris Kasprzak. Thanks for their great work!

Currently only I2C Protocol is supported and it is tested on STM32G0. 

Guide：https://zhuanlan.zhihu.com/p/624251644
